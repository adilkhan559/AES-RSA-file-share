from __future__ import annotations

import subprocess
import sys
from datetime import datetime
from pathlib import Path

# Allow importing from src/ (for reading manifest + finding ciphertext)
PROJECT_ROOT = Path(__file__).resolve().parents[1]
SRC_DIR = PROJECT_ROOT / "src"
sys.path.append(str(SRC_DIR))

from secure_backup.config import AppPaths
from secure_backup.users import create_user_rsa_keys, user_key_paths
from secure_backup.manifest import read_manifest

# Set False if you want it to run without pauses
PAUSE_BETWEEN_STEPS = True


def pause(msg: str) -> None:
    if PAUSE_BETWEEN_STEPS:
        input(f"\n{msg} (press Enter) ")


def ts() -> str:
    return datetime.now().strftime("%Y%m%d_%H%M%S")


def run_cmd(args: list[str], expect_ok: bool = True) -> int:
    """Run a command and show it on screen (good for video)."""
    print(f"\n$ {' '.join(args)}")
    r = subprocess.run(args)
    if expect_ok and r.returncode != 0:
        raise SystemExit(f"[FAIL] Command failed with code {r.returncode}")
    return r.returncode


def ensure_user(paths: AppPaths, user_id: str) -> None:
    """Create the user if keys are missing (prompts for password on creation)."""
    kp = user_key_paths(paths.keystore, user_id)
    if kp.public_path.exists() and kp.private_path.exists():
        print(f"[OK] User exists: {user_id}")
        return
    print(f"[INFO] Creating user: {user_id}")
    create_user_rsa_keys(paths.keystore, user_id)  # prompts for password


def reset_demo_folder(demo_dir: Path) -> None:
    """Make demo input consistent every run."""
    if demo_dir.exists():
        for p in demo_dir.rglob("*"):
            if p.is_file():
                p.unlink()
    demo_dir.mkdir(parents=True, exist_ok=True)
    (demo_dir / "a.txt").write_text("secret A\n", encoding="utf-8")
    (demo_dir / "b.txt").write_text("secret B\n", encoding="utf-8")
    print(f"[OK] Demo folder ready: {demo_dir}")


def print_manifest_highlights(backup_dir: Path) -> None:
    m = read_manifest(backup_dir / "manifest.json")
    f0 = m["files"][0]
    print("\n--- Manifest highlights (what the backup stores) ---")
    print(f"Signer:      {m.get('signer_user_id')}")
    print(f"Recipients:  {m.get('recipients')}")
    print(f"Algorithms:  {m.get('algorithms')}")
    print(f"Files count: {len(m.get('files', []))}")
    print("\nFirst file entry:")
    print(f"  path:               {f0.get('path')}")
    print(f"  cipher_path:        {f0.get('cipher_path')}")
    print(f"  wrapped_keys users: {list(f0.get('wrapped_keys', {}).keys())}")
    print("---------------------------------------------------\n")


def compare_text_files(src_plain: Path, restored_plain: Path) -> None:
    if src_plain.read_text(encoding="utf-8") != restored_plain.read_text(encoding="utf-8"):
        raise SystemExit(f"[FAIL] Restored mismatch: {restored_plain}")
    print(f"[OK] Restored matches original: {restored_plain.name}")


def tamper_ciphertext(backup_dir: Path) -> None:
    """Append 1 byte to ciphertext to prove integrity checks work."""
    m = read_manifest(backup_dir / "manifest.json")
    first = m["files"][0]
    cipher_path = backup_dir / first["cipher_path"]
    print(f"[INFO] Tampering with ciphertext: {cipher_path}")
    with cipher_path.open("ab") as f:
        f.write(b"X")


def main() -> None:
    paths = AppPaths(PROJECT_ROOT)
    paths.ensure()

    py = sys.executable  # venv python if venv is active

    demo_folder = PROJECT_ROOT / "demo" / "video_data"

    # Use stable names so it’s easy to follow on video (Option A cleans first anyway)
    backup_dir = PROJECT_ROOT / "backups" / f"video_demo_{ts()}"
    alice_only_dir = PROJECT_ROOT / "backups" / f"alice_only_{ts()}"
    out_bob = PROJECT_ROOT / "restored" / f"bob_out_{ts()}"
    out_alice = PROJECT_ROOT / "restored" / f"alice_out_{ts()}"
    out_bob_fail = PROJECT_ROOT / "restored" / f"bob_should_fail_{ts()}"

    print("==============================================================")
    print("DEMO: Secure Backup (AES-GCM + RSA-OAEP + RSA-PSS) — 10 Features")
    print("==============================================================")
    print(f"Project root: {PROJECT_ROOT}")

    pause("Start demo")

    # Feature 8 is CLI workflow; show doctor first.
    print("\nFeature 8 — Clear CLI workflow + inputs/outputs shown")
    run_cmd([py, "src/main.py", "doctor"])
    pause("Next: Feature 1/7 key setup")

    print("\nFeature 7 — Protect private keys (encrypted at rest) + separate users")
    ensure_user(paths, "alice")
    ensure_user(paths, "bob")
    print(f"[INFO] Keystore public:  {paths.public_keys}")
    print(f"[INFO] Keystore private: {paths.private_keys} (encrypted-at-rest; password prompt when used)")
    pause("Next: Feature 1 folder backup")

    print("\nFeature 1 — Folder backup (not just single file)")
    reset_demo_folder(demo_folder)
    print("[INFO] Plaintext sample a.txt:")
    print((demo_folder / "a.txt").read_text(encoding="utf-8").strip())
    pause("Next: backup (AES + RSA)")

    print("\nFeature 2 — AES authenticated encryption (confidentiality + integrity)")
    print("Feature 3 — Per-file random AES key (and unique nonce per file)")
    print("Feature 4 — RSA key wrapping for multi-user access (secure key sharing)")
    print("Feature 5 — RSA digital signatures for authenticity")
    print("Feature 6 — Hashing for integrity auditing (ciphertext SHA-256 stored + checked)")
    print("Feature 8 — CLI backup command (inputs/outputs shown)")
    run_cmd(
        [
            py, "src/main.py", "backup",
            str(demo_folder),
            "--recipients", "alice,bob",
            "--signer", "alice",
            "--out", str(backup_dir),
        ]
    )

    print_manifest_highlights(backup_dir)
    pause("Next: verify")

    print("\nFeature 5/6 — Verify signature + ciphertext hashes (verify without restoring)")
    run_cmd([py, "src/main.py", "verify", str(backup_dir), "--signer", "alice"])
    pause("Next: restore as Bob")

    print("\nFeature 9 — Demonstration cases: decrypt successfully as Bob")
    run_cmd([py, "src/main.py", "restore", str(backup_dir), "--user", "bob", "--out", str(out_bob)])
    compare_text_files(demo_folder / "a.txt", out_bob / "a.txt")
    compare_text_files(demo_folder / "b.txt", out_bob / "b.txt")
    pause("Next: restore as Alice")

    print("\nFeature 9 — Demonstration cases: decrypt successfully as Alice")
    run_cmd([py, "src/main.py", "restore", str(backup_dir), "--user", "alice", "--out", str(out_alice)])
    compare_text_files(demo_folder / "a.txt", out_alice / "a.txt")
    compare_text_files(demo_folder / "b.txt", out_alice / "b.txt")
    pause("Next: non-recipient failure")

    print("\nFeature 9 — Attempt decrypt with wrong user (should fail)")
    run_cmd(
        [
            py, "src/main.py", "backup",
            str(demo_folder),
            "--recipients", "alice",
            "--signer", "alice",
            "--out", str(alice_only_dir),
        ]
    )

    # This should fail (bob not a recipient). We expect non-zero.
    rc = run_cmd([py, "src/main.py", "restore", str(alice_only_dir), "--user", "bob", "--out", str(out_bob_fail)], expect_ok=False)
    if rc == 0:
        raise SystemExit("[FAIL] Unexpected: Bob restored alice-only backup")
    print("[OK] Expected failure happened (Bob not authorised).")
    pause("Next: tamper detection")

    print("\nFeature 9 — Tamper with ciphertext then verify fails (integrity + authenticity proof)")
    tamper_ciphertext(backup_dir)
    rc = run_cmd([py, "src/main.py", "verify", str(backup_dir), "--signer", "alice"], expect_ok=False)
    if rc == 0:
        raise SystemExit("[FAIL] Unexpected: verify passed after tampering")
    print("[OK] Expected failure happened (tamper detected).")

 
    print("\nDEMO COMPLETE.")


if __name__ == "__main__":
    main()
