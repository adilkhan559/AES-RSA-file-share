from __future__ import annotations

import os
from pathlib import Path

# Make "src/" importable when running from demo/
import sys
sys.path.append(str(Path(__file__).resolve().parents[1] / "src"))

from secure_backup.crypto_rsa import (
    wrap_aes_key_with_rsa,
    unwrap_aes_key_with_rsa,
    sign_bytes_rsa_pss,
    verify_bytes_rsa_pss,
)
from secure_backup.crypto_aes import encrypt_file_aes_gcm, decrypt_file_aes_gcm
from secure_backup.users import load_user_public_key, load_user_private_key


def main() -> None:
    project_root = Path(__file__).resolve().parents[1]
    keystore_dir = project_root / "keystore"

    # ---------- 1) RSA wrap/unwrap test ----------
    print("1) RSA wrap/unwrap test")
    alice_pub = load_user_public_key(keystore_dir, "alice")
    alice_priv = load_user_private_key(keystore_dir, "alice")  # prompts password

    aes_key = os.urandom(32)  # AES-256 key
    wrapped = wrap_aes_key_with_rsa(alice_pub, aes_key)
    unwrapped = unwrap_aes_key_with_rsa(alice_priv, wrapped)

    if unwrapped != aes_key:
        raise SystemExit("FAIL: RSA unwrap did not match original AES key")
    print("   OK: RSA wrap/unwrap works")

    # ---------- 2) RSA sign/verify test ----------
    print("2) RSA sign/verify test")
    test_bytes = b"manifest-bytes-example"
    sig = sign_bytes_rsa_pss(alice_priv, test_bytes)
    verify_bytes_rsa_pss(alice_pub, sig, test_bytes)
    print("   OK: RSA sign/verify works")

    # ---------- 3) AES-GCM file encrypt/decrypt test ----------
    print("3) AES-GCM file encrypt/decrypt test")
    demo_plain = project_root / "demo" / "plain.txt"
    demo_plain.write_text("hello from step 2\n", encoding="utf-8")

    nonce = os.urandom(12)  # recommended GCM nonce length
    enc_path = project_root / "demo" / "plain.txt.enc"
    dec_path = project_root / "demo" / "plain.decrypted.txt"

    tag, cipher_sha = encrypt_file_aes_gcm(demo_plain, enc_path, aes_key, nonce)
    decrypt_file_aes_gcm(enc_path, dec_path, aes_key, nonce, tag)

    if dec_path.read_text(encoding="utf-8") != demo_plain.read_text(encoding="utf-8"):
        raise SystemExit("FAIL: Decrypted text does not match original")
    print("   OK: AES-GCM encrypt/decrypt works")

    print("\nStep 2 smoke test PASSED")


if __name__ == "__main__":
    main()
