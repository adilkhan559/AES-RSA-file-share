from __future__ import annotations

"""
crypto_rsa.py

Small RSA helpers used by the backup workflow:

- RSA-OAEP: to "wrap" (encrypt) the AES file key for each recipient.
- RSA-PSS: to sign the manifest so edits are detected.
"""

from cryptography.hazmat.primitives import hashes
from cryptography.hazmat.primitives.asymmetric import padding

# OAEP label = a small "context string".
# This helps make sure OAEP ciphertexts from other contexts/protocols
# are not accidentally accepted here.
OAEP_LABEL = b"SECURE_BACKUP_AES_KEY_V1"


def wrap_aes_key_with_rsa(public_key, aes_key: bytes) -> bytes:
    """
    Wrap (RSA-encrypt) the AES key using the recipient's public key.
    Only the matching private key can unwrap it.
    """
    return public_key.encrypt(
        aes_key,
        padding.OAEP(
            mgf=padding.MGF1(algorithm=hashes.SHA256()),
            algorithm=hashes.SHA256(),
            label=OAEP_LABEL,
        ),
    )


def unwrap_aes_key_with_rsa(private_key, wrapped_key: bytes) -> bytes:
    """
    Unwrap (RSA-decrypt) the AES key using the recipient's private key.
    """
    return private_key.decrypt(
        wrapped_key,
        padding.OAEP(
            mgf=padding.MGF1(algorithm=hashes.SHA256()),
            algorithm=hashes.SHA256(),
            label=OAEP_LABEL,
        ),
    )


def sign_bytes_rsa_pss(private_key, data: bytes) -> bytes:
    """Sign bytes with RSA-PSS (used for manifest.json)."""
    return private_key.sign(
        data,
        padding.PSS(
            mgf=padding.MGF1(hashes.SHA256()),
            salt_length=padding.PSS.MAX_LENGTH,
        ),
        hashes.SHA256(),
    )


def verify_bytes_rsa_pss(public_key, signature: bytes, data: bytes) -> None:
    """
    Verify RSA-PSS signature.
    Raises InvalidSignature if signature/data/key do not match.
    """
    public_key.verify(
        signature,
        data,
        padding.PSS(
            mgf=padding.MGF1(hashes.SHA256()),
            salt_length=padding.PSS.MAX_LENGTH,
        ),
        hashes.SHA256(),
    )
