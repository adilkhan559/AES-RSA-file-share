from __future__ import annotations

import getpass
from dataclasses import dataclass
from pathlib import Path

from cryptography.hazmat.primitives import serialization
from cryptography.hazmat.primitives.asymmetric import rsa
from cryptography.hazmat.primitives.serialization import load_pem_public_key, load_pem_private_key
import getpass

@dataclass(frozen=True)
class KeyPaths:
    public_path: Path
    private_path: Path


def user_key_paths(keystore_dir: Path, user_id: str) -> KeyPaths:
    pub = keystore_dir / "public" / f"{user_id}_pub.pem"
    priv = keystore_dir / "private" / f"{user_id}_priv.pem"
    return KeyPaths(public_path=pub, private_path=priv)


def create_user_rsa_keys(keystore_dir: Path, user_id: str, key_size: int = 3072) -> KeyPaths:
    """
    Create an RSA keypair for a user.

    - Public key is stored unencrypted (safe to distribute).
    - Private key is stored encrypted using a user-provided password.

    This supports multi-user key management: each user has a distinct private key.
    """
    keystore_dir.mkdir(parents=True, exist_ok=True)
    (keystore_dir / "public").mkdir(parents=True, exist_ok=True)
    (keystore_dir / "private").mkdir(parents=True, exist_ok=True)

    paths = user_key_paths(keystore_dir, user_id)

    if paths.public_path.exists() or paths.private_path.exists():
        raise FileExistsError(f"Keys already exist for user '{user_id}'")

    password = getpass.getpass(f"Set password to encrypt private key for '{user_id}': ").encode("utf-8")
    if len(password) < 8:
        raise ValueError("Password too short (use at least 8 characters).")

    private_key = rsa.generate_private_key(public_exponent=65537, key_size=key_size)
    public_key = private_key.public_key()

    public_pem = public_key.public_bytes(
        encoding=serialization.Encoding.PEM,
        format=serialization.PublicFormat.SubjectPublicKeyInfo,
    )

    private_pem = private_key.private_bytes(
        encoding=serialization.Encoding.PEM,
        format=serialization.PrivateFormat.PKCS8,
        encryption_algorithm=serialization.BestAvailableEncryption(password),
    )

    paths.public_path.write_bytes(public_pem)
    paths.private_path.write_bytes(private_pem)

    return paths
def load_user_public_key(keystore_dir: Path, user_id: str):
    paths = user_key_paths(keystore_dir, user_id)
    if not paths.public_path.exists():
        raise FileNotFoundError(f"Missing public key for '{user_id}': {paths.public_path}")
    return load_pem_public_key(paths.public_path.read_bytes())


def load_user_private_key(keystore_dir: Path, user_id: str, password: bytes | None = None):
    paths = user_key_paths(keystore_dir, user_id)
    if not paths.private_path.exists():
        raise FileNotFoundError(f"Missing private key for '{user_id}': {paths.private_path}")
    if password is None:
        password = getpass.getpass(f"Password for private key '{user_id}': ").encode("utf-8")
    return load_pem_private_key(paths.private_path.read_bytes(), password=password)
