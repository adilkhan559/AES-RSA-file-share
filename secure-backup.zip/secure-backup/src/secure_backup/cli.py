from __future__ import annotations

"""
cli.py

Command-line interface for the secure backup tool.
This file only parses arguments and calls the real functions.
"""

import argparse
from pathlib import Path

from .backup import create_backup, restore_backup, verify_backup
from .config import AppPaths
from .users import create_user_rsa_keys


def build_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(prog="secure-backup")
    p.add_argument("--root", default=".", help="Project root (default: current directory)")
    sub = p.add_subparsers(dest="cmd", required=True)

    # doctor: quick sanity check
    sub.add_parser("doctor", help="Check folders exist and tool runs")

    # init-user: generate keys for a new user
    p_init = sub.add_parser("init-user", help="Create a new RSA keypair for a user")
    p_init.add_argument("user_id")
    p_init.add_argument("--key-size", type=int, default=3072)

    # backup: encrypt file/folder + write manifest + signature
    p_bk = sub.add_parser("backup", help="Encrypt a file/folder into a backup directory")
    p_bk.add_argument("input_path")
    p_bk.add_argument("--recipients", required=True, help="Comma-separated user IDs (e.g., alice,bob)")
    p_bk.add_argument("--signer", required=True, help="User ID that signs the manifest")
    p_bk.add_argument("--out", required=True, help="Output backup directory")

    # verify: check signature + ciphertext hashes
    p_v = sub.add_parser("verify", help="Verify a backup")
    p_v.add_argument("backup_dir")
    # Optional: stronger trust model (verify against an expected signer, not just what's in the manifest)
    p_v.add_argument("--signer", help="Expected signer user ID (recommended)")

    # restore: verify then decrypt as a user
    p_rs = sub.add_parser("restore", help="Verify then decrypt a backup as a user")
    p_rs.add_argument("backup_dir")
    p_rs.add_argument("--user", required=True)
    p_rs.add_argument("--out", required=True)

    return p


def main() -> None:
    args = build_parser().parse_args()

    # AppPaths knows where keystore/backups live under the project root
    paths = AppPaths(Path(args.root).resolve())
    paths.ensure()

    if args.cmd == "doctor":
        print("OK - secure-backup is set up")
        print(f"Root:     {paths.root}")
        print(f"Keystore: {paths.keystore}")
        print(f"Backups:  {paths.backups}")

    elif args.cmd == "init-user":
        kp = create_user_rsa_keys(paths.keystore, args.user_id, key_size=args.key_size)
        print(f"Created user '{args.user_id}'")
        print(f"  Public:  {kp.public_path}")
        print(f"  Private: {kp.private_path} (encrypted)")

    elif args.cmd == "backup":
        recips = [x.strip() for x in args.recipients.split(",") if x.strip()]
        create_backup(
            keystore_dir=paths.keystore,
            input_path=Path(args.input_path),
            out_dir=Path(args.out),
            recipients=recips,
            signer_user_id=args.signer,
        )

    elif args.cmd == "verify":
        verify_backup(
            keystore_dir=paths.keystore,
            backup_dir=Path(args.backup_dir),
            expected_signer_user_id=args.signer,
        )

    elif args.cmd == "restore":
        restore_backup(
            keystore_dir=paths.keystore,
            backup_dir=Path(args.backup_dir),
            user_id=args.user,
            out_dir=Path(args.out),
        )
