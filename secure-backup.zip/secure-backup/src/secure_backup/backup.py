from __future__ import annotations

"""
backup.py
---------

Implements the *workflow* for an encrypted backup system using a standard hybrid design:

- Content encryption (confidentiality + tamper detection):
    AES-256-GCM encrypts each file into ciphertext. AES-GCM produces an authentication
    tag, so decryption fails if ciphertext is modified or if the wrong key/nonce/tag
    is used.

- Key management / secure key sharing (multi-user support):
    For each file, we generate a fresh random AES key.
    That AES key is then RSA-OAEP encrypted ("wrapped") separately for each recipient.
    Only a recipient holding the matching RSA private key can "unwrap" the AES key,
    enabling decryption.

- Manifest + signature (integrity + authenticity):
    We write a JSON manifest containing metadata needed to verify and restore.
    The manifest is signed using RSA-PSS so that any modification of manifest fields
    (recipients, wrapped keys, nonces, tags, hashes, paths, etc.) is detected.

Security note:
- Signatures are only meaningful if the verifier knows *which signer key to trust*.
  If verification chooses the signer from inside the manifest, then an attacker could
  replace both manifest and signature and claim a different signer.
  To support a stronger model, verify_backup() optionally accepts expected_signer_user_id.
"""

import hashlib
import os
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path
from typing import Dict, List, Tuple, Optional

from cryptography.exceptions import InvalidSignature, InvalidTag

from .crypto_aes import encrypt_file_aes_gcm, decrypt_file_aes_gcm
from .crypto_rsa import (
    wrap_aes_key_with_rsa,
    unwrap_aes_key_with_rsa,
    sign_bytes_rsa_pss,
    verify_bytes_rsa_pss,
)
from .manifest import b64e, b64d, write_manifest, read_manifest, canonical_bytes
from .users import load_user_public_key, load_user_private_key


# --- Tunable constants (kept here so the design choices are explicit) ---

AES_KEY_LEN_BYTES = 32      # 32 bytes = 256-bit AES key
GCM_NONCE_LEN_BYTES = 12    # 12 bytes is the recommended nonce length for GCM
HASH_CHUNK_SIZE = 1024 * 1024  # 1 MiB streaming hash chunks


@dataclass(frozen=True)
class BackupLayout:
    """
    Represents the on-disk layout of a backup artifact directory.

    backup_dir/
      files/              <- ciphertext outputs (same structure as input)
      manifest.json       <- metadata needed to verify & restore
      manifest.sig        <- RSA-PSS signature over canonical manifest bytes
    """
    root: Path

    @property
    def files_dir(self) -> Path:
        return self.root / "files"

    @property
    def manifest_path(self) -> Path:
        return self.root / "manifest.json"

    @property
    def sig_path(self) -> Path:
        return self.root / "manifest.sig"


def _collect_files(input_path: Path) -> Tuple[Path, List[Path]]:
    """
    Collect files to encrypt.

    Returns:
      (root_dir, files)

    - If input_path is a file:
        root_dir is its parent and files=[input_path]
    - If input_path is a directory:
        root_dir is the directory itself and files are all files under it recursively

    This is what enables the requirement "backup of files and folders".
    """
    if input_path.is_file():
        return input_path.parent, [input_path]

    if input_path.is_dir():
        files = [p for p in input_path.rglob("*") if p.is_file()]
        return input_path, files

    raise SystemExit(f"Input path not found: {input_path}")


def _sha256_file(path: Path) -> bytes:
    """
    Compute SHA-256 digest of a file in a streaming manner (memory efficient).

    We use this during verify() to detect ciphertext tampering and missing/corrupt files.
    Note: AES-GCM also provides integrity during decrypt, but this allows a fast verify
    step without decrypting any files.
    """
    h = hashlib.sha256()
    with path.open("rb") as f:
        while True:
            chunk = f.read(HASH_CHUNK_SIZE)
            if not chunk:
                break
            h.update(chunk)
    return h.digest()


def create_backup(
    keystore_dir: Path,
    input_path: Path,
    out_dir: Path,
    recipients: List[str],
    signer_user_id: str,
) -> None:
    """
    Create an encrypted backup artifact at out_dir.

    What this function does per file:
      1) Generate a fresh random AES key (AES-256) and nonce (GCM nonce).
      2) Encrypt file bytes with AES-GCM -> ciphertext + tag.
      3) Wrap the AES key for each recipient using RSA-OAEP (recipient public key).
      4) Record metadata (nonce/tag/hash/wrapped keys) in the manifest entry.

    Then overall:
      5) Write manifest.json (canonical JSON format).
      6) Sign canonical manifest bytes using signer private key (RSA-PSS) -> manifest.sig

    Important behavior:
      - The original input files are NOT modified (backup creates an encrypted copy).
      - Private key password is requested for signer_user_id, because signing uses private key.
    """
    layout = BackupLayout(out_dir)
    layout.root.mkdir(parents=True, exist_ok=True)
    layout.files_dir.mkdir(parents=True, exist_ok=True)

    root_dir, files = _collect_files(input_path)

    # Load recipient public keys once (efficient, avoids repeated disk reads).
    # If a recipient doesn't exist in the keystore, this will fail early.
    recipient_pubs = {u: load_user_public_key(keystore_dir, u) for u in recipients}

    # Load signer's private key (encrypted-at-rest). This will prompt for password.
    signer_priv = load_user_private_key(keystore_dir, signer_user_id)

    file_entries: List[Dict[str, object]] = []

    for f in files:
        # Preserve folder structure for directory backups:
        # - If input is a directory, store relative paths (e.g., docs/a.txt)
        # - If input is a single file, store just the filename
        rel = f.relative_to(root_dir).as_posix() if input_path.is_dir() else f.name

        # Where the ciphertext will be written inside the backup artifact
        cipher_rel = rel + ".enc"
        cipher_path = layout.files_dir / cipher_rel
        cipher_path.parent.mkdir(parents=True, exist_ok=True)

        # Per-file content keying:
        # - Fresh AES key per file reduces blast radius if one key is compromised.
        aes_key = os.urandom(AES_KEY_LEN_BYTES)

        # Nonce must be unique per key in GCM. Using os.urandom(12) for each file
        # achieves practical uniqueness here.
        nonce = os.urandom(GCM_NONCE_LEN_BYTES)

        # AES-GCM encryption: returns authentication tag and ciphertext hash.
        tag, cipher_sha = encrypt_file_aes_gcm(f, cipher_path, aes_key, nonce)

        # Secure key sharing:
        # Wrap (RSA encrypt) the AES key separately for each recipient.
        # Stored as base64 so it can be saved in JSON safely.
        wrapped_keys: Dict[str, str] = {
            u: b64e(wrap_aes_key_with_rsa(pub, aes_key))
            for u, pub in recipient_pubs.items()
        }

        file_entries.append(
            {
                # Original plaintext path (relative inside the backup set)
                "path": rel,

                # Ciphertext path within the backup artifact directory
                "cipher_path": f"files/{cipher_rel}",

                # AES-GCM parameters required for decrypt (nonce + tag)
                "nonce_b64": b64e(nonce),
                "tag_b64": b64e(tag),

                # Ciphertext integrity audit: verify() can recompute and compare this.
                "cipher_sha256_b64": b64e(cipher_sha),

                # Per-recipient wrapped AES key (RSA-OAEP ciphertext, base64 encoded)
                "wrapped_keys": wrapped_keys,
            }
        )

    # Manifest includes enough metadata to:
    # - verify integrity (signature + ciphertext hashes)
    # - restore files (nonce/tag + wrapped keys per recipient)
    manifest: Dict[str, object] = {
        "format_version": 1,
        "created_utc": datetime.now(timezone.utc).isoformat().replace("+00:00", "Z"),
        "algorithms": {
            "content_encryption": "AES-256-GCM",
            "key_wrap": "RSA-OAEP-SHA256",
            "signature": "RSA-PSS-SHA256",
            "hash": "SHA-256",
        },
        "input_type": "dir" if input_path.is_dir() else "file",
        "signer_user_id": signer_user_id,
        "recipients": recipients,
        "files": file_entries,
    }

    # Write canonical JSON bytes and sign exactly what was written.
    manifest_bytes = write_manifest(layout.manifest_path, manifest)
    sig = sign_bytes_rsa_pss(signer_priv, manifest_bytes)
    layout.sig_path.write_bytes(sig)

    print(f"Backup created: {layout.root}")
    print(f"  Files:    {layout.files_dir}")
    print(f"  Manifest: {layout.manifest_path}")
    print(f"  Sig:      {layout.sig_path}")


def verify_backup(
    keystore_dir: Path,
    backup_dir: Path,
    expected_signer_user_id: Optional[str] = None,
) -> None:
    """
    Verify a backup artifact.

    Checks performed:
      1) Verify manifest signature (RSA-PSS) -> detects any modification of manifest.json.
      2) Verify ciphertext hashes (SHA-256) -> detects missing/changed encrypted files.

    Trust anchor note:
      - If expected_signer_user_id is provided, we verify using that signer's public key.
        This prevents an attacker from swapping in an entirely new manifest+signature pair
        and claiming a different signer.
      - If not provided, we fall back to signer_user_id stored inside the manifest.
        This still detects tampering, but assumes the environment already trusts whatever
        signer is referenced by the manifest.
    """
    layout = BackupLayout(backup_dir)
    if not layout.manifest_path.exists() or not layout.sig_path.exists():
        raise SystemExit("Backup is missing manifest.json or manifest.sig")

    manifest = read_manifest(layout.manifest_path)

    # Choose signer identity:
    # - Strong mode: externally expected signer
    # - Convenience mode: signer embedded in manifest
    signer = expected_signer_user_id or str(manifest.get("signer_user_id"))
    signer_pub = load_user_public_key(keystore_dir, signer)

    sig = layout.sig_path.read_bytes()

    # Verify signature over canonical JSON bytes so formatting does not break verification.
    try:
        verify_bytes_rsa_pss(signer_pub, sig, canonical_bytes(manifest))
    except InvalidSignature:
        raise SystemExit("VERIFY FAILED: signature invalid (manifest altered or wrong signer key).")

    # Verify ciphertext hashes (fast tamper detection without decrypting).
    for f in manifest.get("files", []):
        cipher_path = backup_dir / str(f["cipher_path"])
        if not cipher_path.exists():
            raise SystemExit(f"VERIFY FAILED: missing ciphertext {cipher_path}")

        actual = _sha256_file(cipher_path)
        expected = b64d(str(f["cipher_sha256_b64"]))
        if actual != expected:
            raise SystemExit(f"VERIFY FAILED: ciphertext hash mismatch for {f['path']}")

    print("Verification OK (signature + ciphertext hashes).")


def restore_backup(keystore_dir: Path, backup_dir: Path, user_id: str, out_dir: Path) -> None:
    """
    Restore (decrypt) a backup artifact as a specific user.

    Steps:
      1) verify_backup() runs first to ensure manifest + ciphertext integrity.
      2) Load user's encrypted RSA private key (prompts for password).
      3) For each file entry:
          - Confirm user_id has a wrapped key entry (access control).
          - Unwrap AES key using RSA-OAEP and user's private key.
          - Decrypt ciphertext using AES-GCM nonce + tag.
          - Write plaintext to out_dir preserving relative structure.

    Important behavior:
      - Users not listed as recipients cannot decrypt because they have no wrapped AES key.
      - If ciphertext is modified, AES-GCM tag validation fails (InvalidTag) and restore aborts.
    """
    verify_backup(keystore_dir, backup_dir)

    layout = BackupLayout(backup_dir)
    manifest = read_manifest(layout.manifest_path)

    # Private key is encrypted-at-rest and requires password to load.
    priv = load_user_private_key(keystore_dir, user_id)

    out_dir.mkdir(parents=True, exist_ok=True)

    for f in manifest.get("files", []):
        wrapped_keys = f["wrapped_keys"]
        if user_id not in wrapped_keys:
            raise SystemExit(f"User '{user_id}' not authorised to decrypt: {f['path']}")

        # Recover the per-file AES key using user's private RSA key.
        aes_key = unwrap_aes_key_with_rsa(priv, b64d(wrapped_keys[user_id]))

        # Recover AES-GCM parameters from manifest.
        nonce = b64d(f["nonce_b64"])
        tag = b64d(f["tag_b64"])

        cipher_path = backup_dir / f["cipher_path"]
        plain_path = out_dir / f["path"]
        plain_path.parent.mkdir(parents=True, exist_ok=True)

        try:
            decrypt_file_aes_gcm(cipher_path, plain_path, aes_key, nonce, tag)
        except InvalidTag:
            # InvalidTag means integrity/authentication failed (tampering or wrong key/nonce/tag).
            raise SystemExit(f"DECRYPT FAILED (GCM tag invalid): {f['path']}")

    print(f"Restore complete: {out_dir.resolve()}")
