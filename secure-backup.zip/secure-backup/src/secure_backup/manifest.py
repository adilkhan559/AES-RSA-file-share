from __future__ import annotations

"""
manifest.py

Small helpers for reading/writing the backup manifest.

- JSON can't store raw bytes, so we Base64-encode things like nonce/tag/hashes/wrapped keys.
- We sign the manifest, so we need a *stable* JSON byte format. canonical_bytes() makes
  sure the same manifest always produces the same bytes (same key order, no extra spaces).
"""

import base64
import json
from pathlib import Path
from typing import Any, Dict


def b64e(b: bytes) -> str:
    """Bytes -> Base64 string (safe to store in JSON)."""
    return base64.b64encode(b).decode("ascii")


def b64d(s: str) -> bytes:
    """Base64 string -> original bytes."""
    return base64.b64decode(s.encode("ascii"))


def canonical_bytes(manifest: Dict[str, Any]) -> bytes:
    """
    Convert manifest dict to deterministic JSON bytes.

    Important: signature verification will fail if JSON formatting changes.
    """
    return json.dumps(
        manifest,
        sort_keys=True,           # stable key ordering
        separators=(",", ":"),    # no spaces
        ensure_ascii=False,
    ).encode("utf-8")


def write_manifest(path: Path, manifest: Dict[str, Any]) -> bytes:
    """Write canonical manifest.json and return the exact bytes written (for signing)."""
    raw = canonical_bytes(manifest)
    path.write_bytes(raw)
    return raw


def read_manifest(path: Path) -> Dict[str, Any]:
    """Read manifest.json into a Python dict."""
    return json.loads(path.read_text(encoding="utf-8"))
