from __future__ import annotations

"""
crypto_aes.py

AES-GCM helpers for encrypting/decrypting file contents.

Why AES-GCM:
- Fast for large files (symmetric crypto)
- Gives confidentiality + integrity (tampering causes decrypt to fail)

Note:
- Nonce must be unique per key. We generate a fresh random nonce per file.
"""

import hashlib
from pathlib import Path
from typing import Tuple

from cryptography.hazmat.primitives.ciphers import Cipher, algorithms, modes

CHUNK_SIZE = 1024 * 1024  # 1 MiB chunks so we don't load big files into RAM


def encrypt_file_aes_gcm(in_path: Path, out_path: Path, key: bytes, nonce: bytes) -> Tuple[bytes, bytes]:
    """
    Encrypt a file using AES-256-GCM (streaming).

    Returns:
      tag: GCM authentication tag (needed for decrypt)
      ciphertext_sha256: hash of ciphertext (used for quick "verify" without decrypting)
    """
    out_path.parent.mkdir(parents=True, exist_ok=True)

    encryptor = Cipher(algorithms.AES(key), modes.GCM(nonce)).encryptor()
    sha = hashlib.sha256()

    with in_path.open("rb") as fin, out_path.open("wb") as fout:
        while True:
            chunk = fin.read(CHUNK_SIZE)
            if not chunk:
                break
            ct = encryptor.update(chunk)
            fout.write(ct)
            sha.update(ct)

        # finalize() gives the last bytes + sets encryptor.tag
        final_ct = encryptor.finalize()
        if final_ct:
            fout.write(final_ct)
            sha.update(final_ct)

    return encryptor.tag, sha.digest()


def decrypt_file_aes_gcm(in_path: Path, out_path: Path, key: bytes, nonce: bytes, tag: bytes) -> bytes:
    """
    Decrypt a file using AES-256-GCM (streaming).

    If ciphertext/nonce/tag/key are wrong or ciphertext was changed, finalize() raises InvalidTag.
    Returns plaintext_sha256 (optional sanity check).
    """
    out_path.parent.mkdir(parents=True, exist_ok=True)

    decryptor = Cipher(algorithms.AES(key), modes.GCM(nonce, tag)).decryptor()
    sha = hashlib.sha256()

    with in_path.open("rb") as fin, out_path.open("wb") as fout:
        while True:
            chunk = fin.read(CHUNK_SIZE)
            if not chunk:
                break
            pt = decryptor.update(chunk)
            fout.write(pt)
            sha.update(pt)

        final_pt = decryptor.finalize()  # raises InvalidTag on tamper/wrong key
        if final_pt:
            fout.write(final_pt)
            sha.update(final_pt)

    return sha.digest()
