from __future__ import annotations

"""
config.py

Keeps all important folders in one place.
This avoids hard-coding paths across the project.
"""

from dataclasses import dataclass
from pathlib import Path


@dataclass(frozen=True)
class AppPaths:
    """Project folder layout (keystore + backups live under root)."""
    root: Path

    @property
    def keystore(self) -> Path:
        """Root of key storage (public/ and private/)."""
        return self.root / "keystore"

    @property
    def public_keys(self) -> Path:
        """Public keys are safe to share."""
        return self.keystore / "public"

    @property
    def private_keys(self) -> Path:
        """Private keys are secret and stored encrypted on disk."""
        return self.keystore / "private"

    @property
    def backups(self) -> Path:
        """Where encrypted backup artifacts are written."""
        return self.root / "backups"

    def ensure(self) -> None:
        """Create required folders if they do not exist."""
        self.public_keys.mkdir(parents=True, exist_ok=True)
        self.private_keys.mkdir(parents=True, exist_ok=True)
        self.backups.mkdir(parents=True, exist_ok=True)
